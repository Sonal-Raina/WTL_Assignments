/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/StatefulEjbClass.java to edit this template
 */
package bankapp;

import javax.ejb.Stateful;

/**
 *
 * @author hp
 */
@Stateful
public class BankTransact implements BankTransactLocal {
    
    // let us consider default balance amount as 10000
    
    
    int balance = 10000;
    
    @Override
    public void deposit(int amount) {
        balance+=amount;
    }

    @Override
    public int withdraw(int amount) {
        balance-=amount;
        return balance;
    }


   
}
